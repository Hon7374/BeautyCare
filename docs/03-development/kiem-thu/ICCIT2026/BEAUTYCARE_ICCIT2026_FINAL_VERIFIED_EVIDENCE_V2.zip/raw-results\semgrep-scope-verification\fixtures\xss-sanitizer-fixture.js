function escapeHtml(value) {
  return String(value).replace(/[<>]/g, '');
}

function render(req, res) {
  const safeValue = escapeHtml(req.query.safe);
  const unsafeValue = req.query.unsafe;
  res.end(`<p>safe=${safeValue}</p><p>unsafe=${unsafeValue}</p>`);
}
