# Semgrep run metadata

## Environment

- OS: Windows 11 Home Single Language, build 26200.
- Python: 3.12.5.
- pip: 24.2.
- Semgrep: 1.182.0.
- Installation: isolated temporary virtual environment at `%TEMP%\beautycare-iccIT-semgrep-venv`; application dependencies and source files were not modified by installation.
- Docker: 29.9.1 client/server; MySQL test container exposed at `127.0.0.1:3310`.
- Git commit hash: unavailable. `git rev-parse HEAD` returned `fatal: not a git repository`; no hash is inferred or substituted.

## Preserved baseline scan

- Rule configuration: `p/owasp-top-ten`.
- Original target: `backend` with `--include '*.js'` and the earlier path exclusions.
- Preserved outputs: `before.json`, `before.sarif`, `after.json`, and `after.sarif`.
- Baseline JSON result: Semgrep 1.182.0, 5 findings, 0 errors, 40 `paths.scanned` entries.
- Baseline timeout records: 5 before remediation and 4 after remediation.

Direct review found that the old JSON discovery listing included three `.env*` paths despite the earlier Markdown exclusion claim. The old artifacts are retained unchanged and are not used as proof of strict secret-file exclusion.

## Corrected scope scan

The corrected run used `--no-git-ignore`, `--include '*.js'`, path-independent exclusions `node_modules`, `.env*`, `logs`, `tests`, and `.runtime-test-mysql`, and `--timeout 0 --timeout-threshold 0`. The target-listing diagnostic selected 37 JavaScript files and explicitly marked `.env*` files as excluded. Outputs are retained separately under `raw-results/semgrep-scope-verification/`.

Corrected result: Semgrep 1.182.0, 37 targets, 70 rules, 5 findings, 0 fatal errors, and 3 residual fixpoint-timeout records. The result is scope-verified but not complete rule coverage for the three timed-out taint contexts.

## Baseline commands

```powershell
$sg = "$env:TEMP\beautycare-iccIT-semgrep-venv\Scripts\semgrep.exe"
$env:PYTHONUTF8 = '1'
& $sg --config p/owasp-top-ten --metrics=off --include '*.js' `
  --exclude 'backend/node_modules' --exclude 'backend/.env*' `
  --exclude 'backend/logs' --exclude 'backend/tests' `
  --json --output docs/03-development/kiem-thu/ICCIT2026/raw-results/semgrep/before.json backend
& $sg --config p/owasp-top-ten --metrics=off --include '*.js' `
  --exclude 'backend/node_modules' --exclude 'backend/.env*' `
  --exclude 'backend/logs' --exclude 'backend/tests' `
  --sarif --output docs/03-development/kiem-thu/ICCIT2026/raw-results/semgrep/before.sarif backend
```

The same two commands were rerun after remediation with `after.json` and `after.sarif`. The first SARIF attempt without `PYTHONUTF8=1` failed with Windows `UnicodeEncodeError` because `cp1252` could not encode `\ufffd`; the UTF-8 retry succeeded.

The corrected-scope command and timeout-zero command are recorded in [12_SEMGREP_SCOPE_VERIFICATION.md](../../12_SEMGREP_SCOPE_VERIFICATION.md). The custom sanitizer fixture and rule are retained with the corrected-scope artifacts.

## Raw outputs

- [Before JSON](before.json)
- [Before SARIF](before.sarif)
- [After JSON](after.json)
- [After SARIF](after.sarif)
- [Corrected scope and timeout evidence](../semgrep-scope-verification/)

The five post-remediation findings are retained as tool findings. Manual review and the XSS regression tests confirm that the interpolated values are escaped, but the Semgrep OSS taint engine does not model the project-local `escapeHtml` sanitizer in the original ruleset. Therefore the result is not reported as zero vulnerabilities.
