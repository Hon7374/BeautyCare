# CSRF evidence note

No standalone `raw-results/csrf` JSON artifact exists in the repository. CSRF coverage is executable and retained inside the machine-readable security Jest result (`raw-results/security-tests/rerun-20261021-1830/smoke-jest.json`) and its source snapshot under `test-sources/backend/tests/security.no-db.test.js`. This directory is a provenance note, not a fabricated result.
