# ICCIT 2026 raw-results index

No original JSON, console log or production data was copied or modified here.

Retained load artifacts are referenced in `docs/03-development/kiem-thu/ICCIT2026/08_REPRODUCIBILITY_MANIFEST.md` and remain under `results/iccIT-replication/` or `results/`. New DB-backed raw results should be placed in a run-specific subdirectory only after a disposable MySQL run completes, together with a redacted manifest and console log.
